# cricket-score-predictor
A XgBoost based Cricket Score Predictor

Dataset: https://www.kaggle.com/veeralakrishna/cricsheet-a-retrosheet-for-cricket?select=t20s
